var configure = function () {
    this.setDefaultTimeout(60 * 1000);
};

module.exports = configure;
