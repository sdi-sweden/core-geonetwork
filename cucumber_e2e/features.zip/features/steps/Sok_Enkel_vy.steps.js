﻿//http://chaijs.com/
var chai = require('chai');

//https://github.com/domenic/chai-as-promised/
var chaiAsPromised = require('chai-as-promised');
chai.use(chaiAsPromised);
var expect = chai.expect;
var titleElement;
var	EC = protractor.ExpectedConditions;
var ResultList = require('../pages/ResultList.js');
list = new ResultList();
var SearchFilter = require('../pages/filter.js');
searchfilter = new SearchFilter();
module.exports = function() {

	this.Given(/^that the user is in Enkel vy$/, function (callback) {

callback();

	//	expect(searchfilter.pageTitle).to.eventually.equal('-').and.notify(callback);
	});

	this.When(/^the user enters the text "([^"]*)" in the fritext field$/, function (arg1, callback) {
		browser.wait(EC.visibilityOf(searchfilter.searchElement), 2000).then(function(){
			searchfilter.freeTextSearch(arg1);
	});
	callback();
	});

	/*
	Funktion för att hämta verifiera title i resultatlistans första post
	*/
	this.Then(/^"([^"]*)" is listed$/, function (arg1, callback) {
 		browser.driver.sleep(3000);
		titleElement = list.resultList.get(0).element(by.css('h1.ng-binding'));
		browser.wait(EC.visibilityOf(titleElement), 20000).then(function(){
			expect(titleElement.getText()).to.eventually.equal(arg1).and.notify(callback);
		});
	});

	/*
	Funktion för att selektera ämne i enkel vy
	*/
	this.When(/^the user select amne "([^"]*)"$/, function (arg1, callback) {

		browser.wait(EC.visibilityOf(element(by.partialLinkText(arg1))), 2000).then(function(){
				element(by.partialLinkText(arg1)).click();
		});
		callback();
	});

	this.When(/^the user combine amne "([^"]*)" with entering the text "([^"]*)" in the fritext field$/, function (arg1, arg2, callback) {
		searchfilter.selectCategory(arg1);
		searchfilter.freeTextSearch(arg2);
		callback();
	});

  this.Given(/^the user has clicked Amne "([^"]*)"$/, function (arg1, callback) {
        searchfilter.selectCategory(arg1);
         callback();
       });

	this.When(/^the user deselects Amne "([^"]*)"$/, function (arg1, callback) {
		searchfilter.selectCategory(arg1)
		callback();
	});

	this.When(/^clicks Amne "([^"]*)"$/, function (arg1, callback) {
			searchfilter.selectCategory(arg1)
		callback();
	});



}
